import baccarat1 from 'src/assets/baccaratTables/1.png'
import baccarat2 from 'src/assets/baccaratTables/2.png'
import baccarat3 from 'src/assets/baccaratTables/3.png'
import baccarat4 from 'src/assets/baccaratTables/4.png'
import baccarat5 from 'src/assets/baccaratTables/5.png'
import baccarat6 from 'src/assets/baccaratTables/6.png'
import baccarat7 from 'src/assets/baccaratTables/7.png'
import baccarat8 from 'src/assets/baccaratTables/8.png'
import baccarat9 from 'src/assets/baccaratTables/9.png'
import baccarat10 from 'src/assets/baccaratTables/10.png'
import baccarat11 from 'src/assets/baccaratTables/11.png'
import baccarat12 from 'src/assets/baccaratTables/12.png'
import baccarat13 from 'src/assets/baccaratTables/13.png'
import baccarat14 from 'src/assets/baccaratTables/14.png'
import baccarat15 from 'src/assets/baccaratTables/15.png'
import baccarat16 from 'src/assets/baccaratTables/16.png'
import baccarat17 from 'src/assets/baccaratTables/17.png'
import baccarat18 from 'src/assets/baccaratTables/18.png'
import baccarat19 from 'src/assets/baccaratTables/19.png'
import baccarat20 from 'src/assets/baccaratTables/20.png'
import baccarat21 from 'src/assets/baccaratTables/21.png'


export const BaccaratTables = [
    {table:baccarat1},
    {table:baccarat2},
    {table:baccarat3},
    {table:baccarat4},
    {table:baccarat5},
    {table:baccarat6},
    {table:baccarat7},
    {table:baccarat8},
    {table:baccarat9},
    {table:baccarat10},
    {table:baccarat11},
    {table:baccarat12},
    {table:baccarat13},
    {table:baccarat14},
    {table:baccarat15},
    {table:baccarat16},
    {table:baccarat17},
    {table:baccarat18},
    {table:baccarat19},
    {table:baccarat20},
    {table:baccarat21},
    ]