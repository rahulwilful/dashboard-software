import React from 'react'

const TableComponent = () => {
  return (
    <div>
      <h1>Table</h1>
    </div>
  )
}

export default TableComponent
